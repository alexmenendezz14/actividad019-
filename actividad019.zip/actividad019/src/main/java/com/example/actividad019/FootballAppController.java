package com.example.actividad019;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.control.Button;
import javafx.scene.control.ChoiceBox;
import javafx.scene.control.Label;
import javafx.scene.layout.VBox;

public class FootballAppController {

    @FXML
    private VBox teamPage;

    @FXML
    private VBox productPage;

    @FXML
    private VBox paymentPage;

    @FXML
    private ChoiceBox<String> teamChoiceBox;

    @FXML
    private ChoiceBox<String> productChoiceBox;

    @FXML
    private Label purchaseLabel;

    private MongoDBConnection mongoDBConnection;

    public FootballAppController() {
        mongoDBConnection = new MongoDBConnection();
    }

    public void initialize() {
        // Ocultar las páginas de producto y pago al inicio
        productPage.setVisible(false);
        paymentPage.setVisible(false);
    }

    public void nextToProductPage() {
        String selectedTeam = teamChoiceBox.getValue();
        if (selectedTeam != null) {
            teamPage.setVisible(false);
            productPage.setVisible(true);
        }
    }

    public void nextToPaymentPage() {
        String selectedProduct = productChoiceBox.getValue();
        if (selectedProduct != null) {
            productPage.setVisible(false);
            paymentPage.setVisible(true);
            purchaseLabel.setText("¡Compra realizada con éxito!\nHas adquirido un " + selectedProduct + " del equipo " + teamChoiceBox.getValue());
            mongoDBConnection.guardarCompra(selectedProduct, teamChoiceBox.getValue());
        }
    }

    public void pay() {
        // Lógica para el proceso de pago
        // Aquí puedes implementar el proceso real de pago, como conectarte a una pasarela de pago,
        // registrar la compra en una base de datos, etc.
        // Por simplicidad, aquí solo mostramos un mensaje de confirmación.
        System.out.println("Pago realizado con éxito");
    }

    public void handleButtonClick(ActionEvent actionEvent) {
    }
}
