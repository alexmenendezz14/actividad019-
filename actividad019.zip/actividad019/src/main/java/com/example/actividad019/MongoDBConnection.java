package com.example.actividad019;

import com.mongodb.client.MongoClients;
import com.mongodb.client.MongoClient;
import com.mongodb.client.MongoCollection;
import com.mongodb.client.MongoDatabase;
import org.bson.Document;

public class MongoDBConnection {
    private static final String CONNECTION_STRING = "mongodb+srv://alexmenedez:<password>@cluster0.yx7rzjk.mongodb.net/";
    private static final String DATABASE_NAME = "equiposfutbol";

    private MongoClient mongoClient;
    private MongoDatabase database;

    public MongoDBConnection() {
        mongoClient = MongoClients.create(CONNECTION_STRING);
        database = mongoClient.getDatabase(DATABASE_NAME);
    }

    public void guardarCompra(String producto, String equipo) {
        MongoCollection<Document> collection = database.getCollection("compras");

        Document compra = new Document("equipo", equipo)
                .append("producto", producto);

        collection.insertOne(compra);
    }
}


