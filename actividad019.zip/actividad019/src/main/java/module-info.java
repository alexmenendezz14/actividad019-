module com.example.actividad019 {
    requires javafx.controls;
    requires javafx.fxml;

    requires org.kordamp.bootstrapfx.core;
    requires com.almasb.fxgl.all;
    requires org.mongodb.driver.sync.client;
    requires org.mongodb.bson;

    opens com.example.actividad019 to javafx.fxml;
    exports com.example.actividad019;
}